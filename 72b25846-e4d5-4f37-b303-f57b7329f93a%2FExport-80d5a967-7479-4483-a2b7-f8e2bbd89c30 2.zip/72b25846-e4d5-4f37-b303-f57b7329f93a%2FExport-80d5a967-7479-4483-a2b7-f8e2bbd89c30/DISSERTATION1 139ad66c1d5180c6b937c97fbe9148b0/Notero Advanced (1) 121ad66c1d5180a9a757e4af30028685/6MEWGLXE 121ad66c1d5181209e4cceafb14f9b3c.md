# 6MEWGLXE

Reading Status: To Find
Title: Cancer Stem Cells, Hypoxia and Metastasis
DOI: 10.1016/J.SEMRADONC.2008.12.002
Abstract Note: The successful growth of a metastasis, by definition, requires the presence of at least 1 cancer stem cell. Metastasis is a complex process, and an important contributor to this process is the influence of the tissue microenvironment, both cell-cell and cell-matrix interactions and the pathophysiologic conditions in tumors, such as hypoxia. A number of studies have suggested that normal stem cells may reside in "niches," where cell-cell and cell-matrix interactions can provide critical signals to support and maintain the undifferentiated phenotype of the stem cells. In this article, the evidence that these niches may be hypoxic is described, and the potential role that hypoxia may play in maintaining the stem cell phenotype in cancers is discussed. Recent work has suggested that there may be a linkage between the stem cell phenotype and that induced by the process of epithelial-mesenchymal transition (EMT). EMT plays an important role in cell movement and organ formation during embryogenesis, and it is currently hypothesized to be a major mechanism by which epithelial cancers may generate cells that can form metastases. Recent evidence suggests that the expression of certain genes involved in EMT is influenced by low oxygen levels, again suggesting a linkage between stem cells and hypoxia. Whether this supposition is correct remains an open question that will only be answered by further experimentation, but the potential role of hypoxia is critical because of its widespread existence in tumors and its known role in resistance to both radiation and drug treatment. © 2009 Elsevier Inc. All rights reserved.
Access Date: 21. Dezember 2023
Author: Hill, Richard P.; Marie-Egyptienne, Delphine T.; Hedley, David W.
Date: 2009-04
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:08 (MESZ)
Extra: 182 citations (Crossref) [2023-12-21] PMID: 19249648
ISSN: 10534296
Issue: 2
Link Attachments: notion://www.notion.so/Hill-et-al-2009-8d197f4bfdd4482384f0e7b372d6b705
Manual Tags: notion
Pages: 106-111
Publication Title: Seminars in Radiation Oncology
Publication Year: 2009
Volume: 19