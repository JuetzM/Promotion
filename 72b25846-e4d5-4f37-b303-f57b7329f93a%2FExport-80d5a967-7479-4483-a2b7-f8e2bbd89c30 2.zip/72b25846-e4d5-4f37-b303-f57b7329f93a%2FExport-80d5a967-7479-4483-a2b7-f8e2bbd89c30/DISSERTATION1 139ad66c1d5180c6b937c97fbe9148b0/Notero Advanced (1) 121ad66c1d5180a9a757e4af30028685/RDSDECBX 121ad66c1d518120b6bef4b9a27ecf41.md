# RDSDECBX

Reading Status: To Find
Title: Histone modifications: Targeting head and neck cancer stem cells
DOI: 10.4252/wjsc.v6.i5.511
Abstract Note: Head and neck squamous cell carcinoma (HNSCC) is the sixth most common cancer worldwide, and is responsible for a quarter of a million deaths annually. The survival rate for HNSCC patients is poor, showing only minor improvement in the last three decades. Despite new surgical techniques and chemotherapy protocols, tumor resistance to chemotherapy remains a significant challenge for HNSCC patients. Numerous mechanisms underlie chemoresistance, including genetic and epigenetic alterations in cancer cells that may be acquired during treatment and activation of mitogenic signaling pathways, such as nuclear factor kappa-light-chain-enhancer-of activated B cell, that cause reduced apoptosis. In addition to dysfunctional molecular signaling, emerging evidence reveals involvement of cancer stem cells (CSCs) in tumor development and in tumor resistance to chemotherapy and radiotherapy. These observations have sparked interest in understanding the mechanisms involved in the control of CSC function and fate. Post-translational modifications of histones dynamically influence gene expression independent of alterations to the DNA sequence. Recent findings from our group have shown that pharmacological induction of post-translational modifications of tumor histones dynamically modulates CSC plasticity. These findings suggest that a better understanding of the biology of CSCs in response to epigenetic switches and pharmacological inhibitors of histone function may directly translate to the development of a mechanism-based strategy to disrupt CSCs. In this review, we present and discuss current knowledge on epigenetic modifications of HNSCC and CSC response to DNA methylation and histone modifications. In addition, we discuss chromatin modifications and their role in tumor resistance to therapy.
Author: Le, John M.; Squarize, Cristiane H.; Castilho, Rogerio M.
Automatic Tags: Head and neck squamous cell carcinoma; Cancer-initiating cell; Chromatin remodeling; Epigenetic marker; Epigenetic target; Histone acetylation; Histone deacetylases inhibitor; Oral squamous cell carcinoma; Tumor resistance
Date: 2014-11-26
Date Added: 3. Mai 2024 09:18 (MESZ)
Date Modified: 14. Mai 2024 11:43 (MESZ)
Extra: PMID: 25426249 PMCID: PMC4178252
File Attachments: /Users/martin/Zotero/storage/QLS35V36/Le et al_2014_Histone modifications.pdf; ; 
ISSN: 1948-0210
Issue: 5
Journal Abbreviation: World J Stem Cells
Language: eng
Library Catalog: PubMed
Link Attachments: notion://www.notion.so/Le-et-al-2014-18a1e70c40304b08aba53cca545f12e1; http://www.ncbi.nlm.nih.gov/pubmed/25426249
Manual Tags: notion
Pages: 511-525
Publication Title: World Journal of Stem Cells
Publication Year: 2014
Short Title: Histone modifications
Volume: 6