# UDPFBVDK

Reading Status: To Find
Title: Hypoxia as a biomarker for radioresistant cancer stem cells
Access Date: 21. Dezember 2023
Author: C, Peitzsch; R, Perrin; RP, Hill; A, Dubrovska; I, Kurth
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 23. April 2024 22:46 (MESZ)
Link Attachments: notion://www.notion.so/C-et-al-o-J-efda7d9913334e2f923f690cb5af37b2
Manual Tags: notion
Pages: 636-52
Publication Title: Int J Radiat Biol
Publication Year: 0
Volume: 90