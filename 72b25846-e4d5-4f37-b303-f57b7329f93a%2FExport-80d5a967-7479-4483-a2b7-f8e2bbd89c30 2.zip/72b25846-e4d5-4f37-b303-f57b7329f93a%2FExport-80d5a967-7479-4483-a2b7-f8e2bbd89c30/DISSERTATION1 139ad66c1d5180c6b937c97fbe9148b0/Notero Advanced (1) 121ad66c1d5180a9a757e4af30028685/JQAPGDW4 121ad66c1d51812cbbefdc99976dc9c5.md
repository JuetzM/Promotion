# JQAPGDW4

Reading Status: To Find
Title: Changes in early and late radiation responses with altered dose fractionation: Implications for dose-survival relationships
DOI: 10.1016/0360-3016(82)90517-X
Abstract Note: Clinical and experimental evidence for divergent changes in early and late radiation responses in normal tissues after changes in dose fractionation indicate a greater sensitivity of late responses to changes in dose per fraction. In experimental studies of the effect of dose per fraction on early and late isoeffects, a larger number-of-fractions exponent for the late responses is the rule. These findings imply that the shape of the dose-survival curve for the target cells whose depletion results in late effects is different from that for target cells for acute effects: as the dose increases the contribution to cell killing from accumulated sublethal injury, relative to killing from single hit events, increases more rapidly in the target cells for late effects. In other words, the survival curve for the target cells for late injury must be "curvier" than that for acute effects. Although such survival curve characteristics are independent of the survival curve model chosen to describe them, they would represent, in terms of the parameters of the linear quadratic model, S = e-αD-βD2, a higher β α ratio for late effects. If the dose survival characteristics of tumor clonogens resemble those of the target cells in acutely responding normal tissues, and if late injury in normal tissues is dose-limiting, then a therapeutic gain would result from reducing the size of dose per fraction by hyperfractionation. Conversely, increasing the size of dose per fraction should reduce the therapeutic differential. © 1982.
Access Date: 21. Dezember 2023
Author: Thames, Howard D.; Rodney Withers, H.; Peters, Lester J.; Fletcher, Gilbert H.
Automatic Tags: Radiotherapy; Dose fractionation; Late effects; Survival curves
Date: 1982
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:17 (MESZ)
Extra: 672 citations (Crossref) [2023-12-21] PMID: 7085377
ISSN: 03603016
Issue: 2
Link Attachments: notion://www.notion.so/Thames-et-al-1982-456eb833dc5d479f82823b4c9e50cd1a
Manual Tags: notion
Pages: 219-226
Publication Title: International Journal of Radiation Oncology, Biology, Physics
Publication Year: 1982
Volume: 8