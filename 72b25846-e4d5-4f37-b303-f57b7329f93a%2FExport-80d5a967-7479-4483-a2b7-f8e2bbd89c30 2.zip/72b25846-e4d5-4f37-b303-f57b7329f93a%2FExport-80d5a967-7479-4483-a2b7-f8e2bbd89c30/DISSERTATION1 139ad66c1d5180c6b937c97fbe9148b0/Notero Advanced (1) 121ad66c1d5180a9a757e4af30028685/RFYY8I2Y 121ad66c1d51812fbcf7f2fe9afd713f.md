# RFYY8I2Y

Reading Status: To Find
Title: CD44 as a stem cell marker in head and neck squamous cell carcinoma
Access Date: 21. Dezember 2023
Author: A, Faber; C, Barth; K, Hormann; S, Kassner; JD, Schultz; U, Sommer
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:14 (MESZ)
Link Attachments: notion://www.notion.so/A-et-al-o-J-c09714f524a7460ca11ded513e6fa8f0
Manual Tags: notion
Pages: 321-6
Publication Title: Oncol Rep
Publication Year: 0
Volume: 26