# 9P9NXUIN

Reading Status: To Find
Title: Diagnostic performance of MRI relative to CT for metastatic nodes of head and neck squamous cell carcinomas
DOI: 10.1002/jmri.21187
URL: https://www.ncbi.nlm.nih.gov/pubmed/17968896
Abstract Note: PURPOSE: To compare the diagnostic abilities of magnetic resonance imaging (MRI) and computed tomography (CT) based on the architectural changes in the nodal parenchyma. MATERIALS AND METHODS: We retrospectively studied histologically proven 70 metastatic and 52 reactive nodes in the necks of 38 patients with head and neck squamous cell carcinomas who had undergone both CT and MRI. We assessed the detectability of the architectural changes in the nodal parenchyma that were suggestive of cancer focus (cancer nest, necrosis, and keratinization). The diagnostic abilities of CT and MRI were assessed by three observers separately for the small (<10 mm in minimum axis diameter) and large (>or=10 mm) nodes. RESULTS: MRI was significantly more effective than CT in diagnosing small metastatic nodes, yielding 83% sensitivity, 88% specificity, and 86% accuracy. However, the diagnostic abilities of MRI and CT were similar for large metastatic nodes; MRI yielded 100% sensitivity, 98% specificity, and 99% accuracy. receiver operating characteristic analysis also indicated that the Az values were significantly higher for MRI than for CT (0.927 vs. 0.822, P = 0.00054) for the detection of small nodes. CONCLUSION: MRI is superior to CT in the diagnosis of metastatic nodes from head and neck squamous cell carcinomas.
Author: Sumi, M.; Kimura, Y.; Sumi, T.; Nakamura, T.
Date: 2007
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:23 (MEZ)
Extra: Type: Journal Article
ISSN: 1053-1807 (Print) 1053-1807 (Linking)
Issue: 6
Link Attachments: notion://www.notion.so/Sumi-et-al-2007-b40cc78a4c6649cdafab21025b87b7a9
Manual Tags: Female; Humans; Male; Middle Aged; Aged; Analysis of Variance; Lymphatic Metastasis; ROC Curve; notion; Carcinoma, Squamous Cell/*diagnosis/diagnostic imaging/pathology; Contrast Media; Gadolinium DTPA; Head and Neck Neoplasms/*diagnosis/diagnostic imaging/pathology; Magnetic Resonance Imaging/*methods; Tomography, Spiral Computed/*methods; Aged Analysis of Variance Carcinoma; Spiral Computed/*methods
Pages: 1626-33
Publication Title: J Magn Reson Imaging
Publication Year: 2007
Volume: 26