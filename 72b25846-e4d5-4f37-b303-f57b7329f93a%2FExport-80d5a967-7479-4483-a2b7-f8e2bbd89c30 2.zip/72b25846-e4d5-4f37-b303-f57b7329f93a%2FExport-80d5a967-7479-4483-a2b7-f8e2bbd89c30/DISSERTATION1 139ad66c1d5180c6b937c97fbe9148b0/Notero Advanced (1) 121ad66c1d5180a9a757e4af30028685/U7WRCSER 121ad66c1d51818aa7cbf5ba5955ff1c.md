# U7WRCSER

Reading Status: To Find
Title: Tumor thickness influences prognosis of T1 and T2 oral cavity cancer–but what thickness?
DOI: 10.1002/hed.10324
URL: https://onlinelibrary.wiley.com/doi/10.1002/hed.10324
Abstract Note: BACKGROUND: Previous studies have demonstrated that tumor thickness might influence prognosis in oral cancer, but the significant point at which outcome changes has varied from 1.5 mm to 6 mm. The clinical relevance of thickness remains unclear, and a reproducible prognostic "breakpoint" needs to be defined. METHODS: Tumor thickness was measured in 145 oral cavity squamous cancers, clinically staged T1 (n = 62) or T2 (n = 83). Clinical and pathologic data were collected prospectively between 1988 and 2000, but thickness was measured on paraffin sections for this study. Minimum follow-up was 2 years, and thickness was correlated with local control, cervical node involvement, and survival. Patients with clinically positive nodes (n = 21) were not excluded. Overall, 55 patients had pathologic node involvement at some time in their disease. RESULTS: Median tumor thickness was 6.2 mm, and there was little variation between sites: tongue, 6.4 mm; floor of mouth, 6.6 mm; and other sites, 5.7 mm. Median thickness for T1 tumors was 4.3 mm, significantly less than the T2 group, 8 mm (p <.01). Median thickness also varied significantly for tumors with associated nodal disease (8.5 mm) and without nodal disease (5.8 mm) (p <.01). Prognosis changed significantly at a cutoff of 4 mm with local control, nodal disease, and survival rates of 91%, 8%, and 100%, respectively, for tumors <4 mm compared with 84%, 48%, and 74% for those 4 mm or more thick (p <.01). Subgrouping greater than and less than 3 mm and 5 mm also showed a difference but with poorer discrimination. Thickness and pathologic nodal involvement were highly significant independent prognostic factors. CONCLUSIONS: Tumor thickness is a highly significant, objectively measurable prognostic factor in early stage oral cancers. There is a need to standardize techniques of measurement to allow a multi-institutional study to be carried out. This will facilitate the development of strategies aimed at improving the outcome of higher risk patients.
Author: O'Brien, C. J.; Lauer, C. S.; Fredricks, S.; Clifford, A. R.; McNeil, E. B.; Bagia, J. S.; Koulmandas, C.
Date: 2003
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 16. Februar 2024 15:29 (MEZ)
Extra: Type: Journal Article
ISSN: 1043-3074 (Print) 1043-3074 (Linking)
Issue: 11
Link Attachments: notion://www.notion.so/O-Brien-et-al-2003-ad76521d3b674d1c9c07f39e4400e8af
Manual Tags: notion; Adult Aged Aged; 80 and over Female Humans Lymphatic Metastasis Male Middle Aged Mouth Neoplasms/*mortality/*pathology Multivariate Analysis Prognosis Survival Analysis Tongue Neoplasms/mortality/pathology
Pages: 937-45
Publication Title: Head Neck
Publication Year: 2003
Volume: 25