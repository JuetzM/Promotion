# SJSAFBPM

Reading Status: To Find
Title: Cancer stem cells–perspectives on current status and future directions: AACR Workshop on cancer stem cells
DOI: 10.1158/0008-5472.CAN-06-3126
URL: https://www.ncbi.nlm.nih.gov/pubmed/16990346
Author: Clarke, M. F.; Dick, J. E.; Dirks, P. B.; Eaves, C. J.; Jamieson, C. H.; Jones, D. L.; Visvader, J.; Weissman, I. L.; Wahl, G. M.
Automatic Tags: Biomarkers, Tumor; Neoplasms; Neoplastic Stem Cells
Date: 2006
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:22 (MEZ)
Extra: Type: Journal Article
File Attachments: ; ; /Users/martin/Zotero/storage/BASYCMWW/Clarke et al. - 2006 - Cancer stem cells–perspectives on current status a.pdf
ISSN: 1538-7445 (Electronic) 0008-5472 (Linking)
Issue: 19
Link Attachments: notion://www.notion.so/Clarke-et-al-2006-74d2a8f943d84567a9ba5211259e467a; http://www.ncbi.nlm.nih.gov/pubmed/16990346
Manual Tags: Humans; Animals; Mice; Mice, Inbred NOD; Mice, SCID; Transplantation, Heterologous; Neoplasm Metastasis; Disease Progression; Neoplasm Transplantation; Tumor Stem Cell Assay; *Neoplastic Stem Cells/chemistry/cytology/transplantation; Biomarkers, Tumor/analysis; Epigenesis, Genetic; Models, Biological; Neoplasms/pathology/therapy; notion; Inbred NOD Mice; Animals Biomarkers; Biological Neoplasm Metastasis Neoplasm Transplantation Neoplasms/pathology/therapy *Neoplastic Stem Cells/chemistry/cytology/transplantation Transplantation; Genetic Humans Mice Mice; Heterologous Tumor Stem Cell Assay; SCID Models; Tumor/analysis Disease Progression Epigenesis
Pages: 9339-44
Publication Title: Cancer Res
Publication Year: 2006
Volume: 66