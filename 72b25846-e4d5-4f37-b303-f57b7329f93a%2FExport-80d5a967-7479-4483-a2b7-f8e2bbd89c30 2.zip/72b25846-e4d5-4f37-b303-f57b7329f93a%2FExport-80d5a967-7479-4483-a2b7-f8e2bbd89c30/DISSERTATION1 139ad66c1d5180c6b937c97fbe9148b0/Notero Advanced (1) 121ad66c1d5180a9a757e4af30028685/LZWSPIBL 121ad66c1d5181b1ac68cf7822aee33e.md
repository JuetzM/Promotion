# LZWSPIBL

Reading Status: To Find
Title: Clinical update on cancer: molecular oncology of head and neck cancer
DOI: 10.1038/cddis.2013.548
URL: https://www.ncbi.nlm.nih.gov/pubmed/24457962
Abstract Note: Head and neck cancers encompass a heterogeneous group of tumours that, in general, are biologically aggressive in nature. These cancers remain difficult to treat and treatment can cause severe, long-term side effects. For patients who are not cured by surgery and/or (chemo)radiotherapy, there are few effective treatment options. Targeted therapies and predictive biomarkers are urgently needed in order to improve the management and minimise the treatment toxicity, and to allow selection of patients who are likely to benefit from both nonselective and targeted therapies. This clinical update aims to provide an insight into the current understanding of the molecular pathogenesis of the disease, and explores the novel therapies under development and in clinical trials.
Author: Suh, Y.; Amelio, I.; Guerrero Urbano, T.; Tavassoli, M.
Date: 2014
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:23 (MEZ)
Extra: Type: Journal Article
File Attachments: ; /Users/martin/Zotero/storage/IHXT7IFG/Suh et al. - 2014 - Clinical update on cancer molecular oncology of h.pdf
ISSN: 2041-4889 (Electronic)
Issue: 1
Link Attachments: notion://www.notion.so/Suh-et-al-2014-8978ad124c114e6183cc40b15302da24
Manual Tags: Humans; Animals; Signal Transduction; notion; Biomarkers; *Molecular Targeted Therapy; Head and Neck Neoplasms/*genetics/metabolism/*therapy; Animals Biomarkers Head and Neck Neoplasms/*genetics/metabolism/*therapy Humans *Molecular Targeted Therapy Signal Transduction
Pages: e1018
Publication Title: Cell Death Dis
Publication Year: 2014
Volume: 5