# PDRMPAWA

Reading Status: To Find
Title: Impact of initial tumor volume on radiotherapy outcome in patients with T2 glottic cancer
Access Date: 21. Dezember 2023
Author: Rutkowski, T.
Date: 2014
Date Added: 21. Dezember 2023 09:11 (MEZ)
Date Modified: 23. April 2024 22:48 (MESZ)
Link Attachments: notion://www.notion.so/Rutkowski-2014-f4c6e4983e5e424a80196c97d611c8f2
Manual Tags: notion
Pages: 480-484
Publication Title: Strahlenther Onkol
Publication Year: 2014
Volume: 190