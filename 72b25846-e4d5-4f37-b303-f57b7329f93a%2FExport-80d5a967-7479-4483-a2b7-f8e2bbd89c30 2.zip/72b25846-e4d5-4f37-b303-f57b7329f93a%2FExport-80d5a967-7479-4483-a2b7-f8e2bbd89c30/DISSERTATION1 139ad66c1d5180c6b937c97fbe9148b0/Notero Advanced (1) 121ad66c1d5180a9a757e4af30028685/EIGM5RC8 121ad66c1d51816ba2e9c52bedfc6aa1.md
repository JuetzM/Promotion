# EIGM5RC8

Reading Status: To Find
Title: Carcinoma of the larynx: the Dutch national guideline for diagnostics, treatment, supportive care and rehabilitation
DOI: 10.1016/s0167-8140(02)00073-7
URL: https://www.thegreenjournal.com/article/S0167-8140(02)00073-7/abstract
Abstract Note: PURPOSE: This evidence based guideline aims to facilitate proper management and to prevent diverging views concerning diagnosis, treatment and follow-up of carcinoma of the larynx between the major referral centers for head and neck cancer in The Netherlands. METHOD: A multidisciplinary committee was formed representing all medical and paramedical disciplines involved in the management of laryngeal cancer and all head and neck oncology centers in The Netherlands. This committee reviewed the literature and formulated statements and recommendations based on the level of evidence and consistency of the literature data. Where reliable literature data were not available, recommendations were based on expert opinion. RESULTS: Strict criteria have been proposed for the radiological diagnostic procedures as well as for the pathology report. For carcinoma in situ and severe dysplasia, microsurgery, preferably by laser, is proposed. For all other stages of invasive carcinoma, a full course of radiotherapy as a voice conserving therapy is the treatment of choice. Only in cases with massive tumor volumes with invasion through the laryngeal skeleton, primary surgery is inevitable. For rehabilitation and supportive care, minimal criteria are described. Due to the complexity of therapy and relative rarity of larynx carcinoma, all patients should be seen at least once in a dedicated head and neck clinic. CONCLUSION: This guideline for the management of larynx carcinoma was produced by a multidisciplinary national committee and based on scientific evidence wherever possible. This procedure of guideline development has created the optimal conditions for nationwide acceptance and implementation of the guideline.
Author: Kaanders, J. H.; Hordijk, G. J.; Dutch Cooperative, Head; Neck Oncology, Group
Date: 2002
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:22 (MEZ)
Extra: Type: Journal Article
ISSN: 0167-8140 (Print) 0167-8140 (Linking)
Issue: 3
Link Attachments: notion://www.notion.so/Kaanders-et-al-2002-d4acf70e260c4b1b975d1604a7996eb7
Manual Tags: Humans; Carcinoma/*diagnosis/rehabilitation/*therapy; Evidence-Based Medicine; Health Policy; Laryngeal Neoplasms/*diagnosis/rehabilitation/*therapy; Larynx; Netherlands; Practice Guidelines as Topic; Social Support; notion; Carcinoma/*diagnosis/rehabilitation/*therapy Evidence-Based Medicine Health Policy Humans Laryngeal Neoplasms/*diagnosis/rehabilitation/*therapy Larynx Netherlands Practice Guidelines as Topic Social Support
Pages: 299-307
Publication Title: Radiother Oncol
Publication Year: 2002
Volume: 63