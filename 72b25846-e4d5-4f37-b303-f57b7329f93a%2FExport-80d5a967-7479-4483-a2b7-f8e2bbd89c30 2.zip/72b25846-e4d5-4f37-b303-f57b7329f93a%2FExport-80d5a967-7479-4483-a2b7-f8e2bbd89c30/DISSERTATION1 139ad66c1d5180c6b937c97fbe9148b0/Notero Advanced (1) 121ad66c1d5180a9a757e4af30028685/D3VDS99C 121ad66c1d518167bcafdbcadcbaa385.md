# D3VDS99C

Reading Status: To Find
Title: Current oncologic concepts and emerging techniques for imaging of head and neck squamous cell cancer
DOI: 10.3205/cto000090
URL: https://www.ncbi.nlm.nih.gov/pubmed/23320060
Abstract Note: The incidence of head and neck squamous cell carcinoma (HNSCC) is increasing and currently they account for 5% of all malignancies worldwide. Inspite of ongoing developments in diagnostic imaging and new therapeutic options, HNSCC still represents a multidisciplinary challenge.One of the most important prognostic factors in HNSCC is the presence of lymph node metastases. Patients with confirmed nodal involvement have a considerable reduction of their 5-year overall survival rate. In the era of individually optimised surgery, chemotherapy and intensity modulated radiotherapy, the main role of pre- and posttherapeutic imaging remains cancer detection at an early stage and accurate follow-up. The combined effort of early diagnosis and close patient monitoring after surgery and/or radio-chemotherapy influences disease progression and outcome predicition in patients with HNSCC.This review article focuses on currrent oncologic concepts and emerging tools in imaging of head and neck squamous cell cancer. Besides the diagnostic spectrum of the individual imaging modalities, their limitations are also discussed. One main part of this article is dedicated to PET-CT which combines functional and morphological imaging. Furthermore latest developments in MRI are presented with regard to lymph node staging and response prediction. Last but not least, a clinical contribution in this review explains, which information the head and neck surgeon requires from the multimodality imaging and its impact on operation planning.
Author: Sadick, M.; Schoenberg, S. O.; Hoermann, K.; Sadick, H.
Date: 2012
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 16. Februar 2024 15:20 (MEZ)
Extra: Type: Journal Article
ISSN: 1865-1011 (Print) 1865-1011 (Electronic) 1865-1011 (Linking)
Link Attachments: notion://www.notion.so/Sadick-et-al-2012-3e9ff9eef22a4dcf9051f55a735839fa
Manual Tags: notion; Hnscc Mri Pet-ct diffusion weighted imaging head and neck carcinoma hypoxia imaging lymph node staging
Pages: Doc08
Publication Title: GMS Curr Top Otorhinolaryngol Head Neck Surg
Publication Year: 2012
Volume: 11