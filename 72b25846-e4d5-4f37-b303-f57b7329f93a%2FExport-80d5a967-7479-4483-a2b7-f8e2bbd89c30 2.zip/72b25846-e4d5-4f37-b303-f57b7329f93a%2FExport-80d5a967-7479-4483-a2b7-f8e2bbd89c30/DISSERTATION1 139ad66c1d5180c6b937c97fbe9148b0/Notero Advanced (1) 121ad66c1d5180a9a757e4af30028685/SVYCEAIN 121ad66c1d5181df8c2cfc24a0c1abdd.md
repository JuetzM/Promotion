# SVYCEAIN

Reading Status: To Find
Title: HNSCC cell lines positive for HPV and p16 possess higher cellular radiosensitivity due to an impaired DSB repair capacity
Access Date: 21. Dezember 2023
Author: Rieckmann, T.; Tribius, S.; Grob, T.J.; Meyer, F.; al., et
Date: 2013
Date Added: 21. Dezember 2023 09:11 (MEZ)
Date Modified: 23. April 2024 22:49 (MESZ)
Link Attachments: notion://www.notion.so/Rieckmann-et-al-2013-427418876bd64f5c823f2bf84d9176fa
Manual Tags: notion
Pages: 242-246
Publication Title: Radiother Oncol
Publication Year: 2013
Volume: 107