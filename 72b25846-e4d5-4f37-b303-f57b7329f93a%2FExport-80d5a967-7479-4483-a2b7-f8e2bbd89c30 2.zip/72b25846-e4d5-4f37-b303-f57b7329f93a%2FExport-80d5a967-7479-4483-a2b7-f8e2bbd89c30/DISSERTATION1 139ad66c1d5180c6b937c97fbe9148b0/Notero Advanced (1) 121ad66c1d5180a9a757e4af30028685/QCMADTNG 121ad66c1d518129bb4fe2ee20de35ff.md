# QCMADTNG

Reading Status: To Find
Title: Evaluation of cancer stem cell markers CD133, CD44, CD24: association with AKT isoforms and radiation resistance in colon cancer cells
DOI: 10.1371/journal.pone.0094621
Abstract Note: The cell surface proteins CD133, CD24 and CD44 are putative markers for cancer stem cell populations in colon cancer, associated with aggressive cancer types and poor prognosis. It is important to understand how these markers may predict treatment outcomes, determined by factors such as radioresistance. The scope of this study was to assess the connection between EGFR, CD133, CD24, and CD44 (including isoforms) expression levels and radiation sensitivity, and furthermore analyze the influence of AKT isoforms on the expression patterns of these markers, to better understand the underlying molecular mechanisms in the cell. Three colon cancer cell-lines were used, HT-29, DLD-1, and HCT116, together with DLD-1 isogenic AKT knock-out cell-lines. All three cell-lines (HT-29, HCT116 and DLD-1) expressed varying amounts of CD133, CD24 and CD44 and the top ten percent of CD133 and CD44 expressing cells (CD133high/CD44high) were more resistant to gamma radiation than the ten percent with lowest expression (CD133low/CD44low). The AKT expression was lower in the fraction of cells with low CD133/CD44. Depletion of AKT1 or AKT2 using knock out cells showed for the first time that CD133 expression was associated with AKT1 but not AKT2, whereas the CD44 expression was influenced by the presence of either AKT1 or AKT2. There were several genes in the cell adhesion pathway which had significantly higher expression in the AKT2 KO cell-line compared to the AKT1 KO cell-line; however important genes in the epithelial to mesenchymal transition pathway (CDH1, VIM, TWIST1, SNAI1, SNAI2, ZEB1, ZEB2, FN1, FOXC2 and CDH2) did not differ. Our results demonstrate that CD133high/CD44high expressing colon cancer cells are associated with AKT and increased radiation resistance, and that different AKT isoforms have varying effects on the expression of cancer stem cell markers, which is an important consideration when targeting AKT in a clinical setting.
Author: Sahlberg, Sara Häggblad; Spiegelberg, Diana; Glimelius, Bengt; Stenerlöw, Bo; Nestor, Marika
Automatic Tags: Humans; Cell Line, Tumor; AC133 Antigen; Antigens, CD; Hyaluronan Receptors; Protein Isoforms; Neoplastic Stem Cells; Glycoproteins; Peptides; CD24 Antigen; Colonic Neoplasms; HCT116 Cells; HT29 Cells; Oncogene Protein v-akt
Date: 2014
Date Added: 3. Mai 2024 09:18 (MESZ)
Date Modified: 14. Mai 2024 11:43 (MESZ)
Extra: PMID: 24760019 PMCID: PMC3997403
File Attachments: ; ; /Users/martin/Zotero/storage/KQ8K72U5/Sahlberg et al_2014_Evaluation of cancer stem cell markers CD133, CD44, CD24.pdf
ISSN: 1932-6203
Issue: 4
Journal Abbreviation: PLoS One
Language: eng
Library Catalog: PubMed
Link Attachments: notion://www.notion.so/Sahlberg-et-al-2014-d0c3da01f19845ef9a2586236ceb6cb5; http://www.ncbi.nlm.nih.gov/pubmed/24760019
Manual Tags: notion
Pages: e94621
Publication Title: PloS One
Publication Year: 2014
Short Title: Evaluation of cancer stem cell markers CD133, CD44, CD24
Volume: 9