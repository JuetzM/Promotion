# 3YECJTS3

Reading Status: To Find
Title: p53 mutations in relation to human papillomavirus type 16 infection in squamous cell carcinomas of the head and neck
DOI: 10.1002/(sici)1097-0215(19970529)71:5<796::aid-ijc17>3.0.co;2-6
URL: https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/%28SICI%291097-0215%2819970529%2971%3A5%3C796%3A%3AAID-IJC17%3E3.0.CO%3B2-6?download=true
Abstract Note: The relationship between human papillomavirus (HPV) type 16 infection and p53 gene mutations was investigated in squamous cell carcinomas of the head and neck (SCCHN). HPV was detected by general primer-mediated and type-specific PCR. Alterations in the p53 gene were investigated using single-strand conformation polymorphism and sequence analysis in 27 SCCHN, of which 12 were HPV 16-positive and 15 were HPV-negative. Mutations were detected in 2/12 (16.7%) HPV 16-positive and 7/15 (46.7%) HPV-negative tumours; this difference was not statistically significant. The predominant mutations were deletions and C –> T transitions; G –> T transversions were found in only 2 tumours. Our results indicate that the presence of HPV 16 and p53 mutations is not mutually exclusive and detection of a p53 mutation does not exclude a potential role for HPV 16 in the pathogenesis of a subset of SCCHN.
Author: Scholes, A. G.; Liloglou, T.; Snijders, P. J.; Hart, C. A.; Jones, A. S.; Woolgar, J. A.; Vaughan, E. D.; Walboomers, J. M.; Field, J. K.
Automatic Tags: Carcinoma, Squamous Cell; Papillomaviridae; Tumor Virus Infections; Head and Neck Neoplasms; Papillomavirus Infections; Genes, p53
Date: 1997
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:26 (MEZ)
Extra: Type: Journal Article
File Attachments: ; 
ISSN: 0020-7136 (Print) 0020-7136 (Linking)
Issue: 5
Link Attachments: notion://www.notion.so/Scholes-et-al-1997-e01abb54cd734fbdbb7850be018d6a3d; http://www.ncbi.nlm.nih.gov/pubmed/9180148
Manual Tags: Humans; Polymerase Chain Reaction; Mutation; notion; Smoking; Carcinoma; *Papillomaviridae/isolation & purification; Carcinoma, Squamous Cell/genetics/*virology; Exons; Gene Deletion; Genes, p53/*genetics; Head and Neck Neoplasms/genetics/*virology; Papillomavirus Infections/*genetics; Polymorphism, Single-Stranded Conformational; Tumor Virus Infections/*genetics; p53/*genetics Head and Neck Neoplasms/genetics/*virology Humans Mutation *Papillomaviridae/isolation & purification Papillomavirus Infections/*genetics Polymerase Chain Reaction Polymorphism; Single-Stranded Conformational Smoking Tumor Virus Infections/*genetics; Squamous Cell/genetics/*virology Exons Gene Deletion Genes
Pages: 796-9
Publication Title: Int J Cancer
Publication Year: 1997
Volume: 71