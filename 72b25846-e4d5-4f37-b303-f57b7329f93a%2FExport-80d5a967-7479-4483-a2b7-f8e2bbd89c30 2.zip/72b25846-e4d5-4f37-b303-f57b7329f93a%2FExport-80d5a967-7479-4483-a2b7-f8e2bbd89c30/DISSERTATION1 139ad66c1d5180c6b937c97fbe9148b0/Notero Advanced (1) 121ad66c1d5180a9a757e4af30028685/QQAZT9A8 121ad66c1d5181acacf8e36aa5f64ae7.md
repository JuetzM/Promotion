# QQAZT9A8

Reading Status: To Find
Title: Influence of the Mediterranean diet on the risk of cancers of the upper aerodigestive tract
URL: https://www.ncbi.nlm.nih.gov/pubmed/14578148
Abstract Note: The hypothesis that the Mediterranean diet has a beneficial role on the risk of cancers of the upper aerodigestive tract has been evaluated using data from three case-control studies conducted in Italy between 1992 and 2000. The first study included 598 cases with incident, histologically confirmed cancers of the oral cavity and pharynx and 1491 hospital controls admitted to the same network of hospitals as cases for acute, nonneoplastic diseases. The second one included 304 subjects with squamous cell carcinoma of the esophagus and 743 controls. The third one included 460 laryngeal cancer cases and 1088 controls. A score summarizing eight of the major characteristics of the Mediterranean diet was used. Odds ratios and corresponding 95% confidence intervals (CIs) for increasing levels of this score were estimated using unconditional regression models, adjusted for age, sex, study center, years of education, tobacco consumption, body mass index, and total energy intake. For all cancers considered, a reduced risk was found for increasing levels of the Mediterranean score: the odds ratios for subjects with six or more Mediterranean characteristics, compared with those with less than three characteristics, were 0.40 (95% CI, 0.26-0.62) for oral and pharyngeal, 0.26 (95% CI, 0.13-0.51) for esophageal, and 0.23 (95% CI, 0.13-0.40) for laryngeal cancer. All of the estimates were consistent in strata of the major identified risk factors for these neoplasms. This study provides evidence that an a priori defined nutritional pattern, which includes several aspects of the Mediterranean diet, favorably affects the risk of cancers of the upper aerodigestive tract.
Author: Bosetti, C.; Gallus, S.; Trichopoulou, A.; Talamini, R.; Franceschi, S.; Negri, E.; La Vecchia, C.
Date: 2003
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:24 (MEZ)
Extra: Type: Journal Article
ISSN: 1055-9965 (Print) 1055-9965 (Linking)
Issue: 10
Link Attachments: notion://www.notion.so/Bosetti-et-al-2003-9acced8e8c584dd6b62e5f658f366945
Manual Tags: Female; Humans; Male; Middle Aged; Risk Factors; Aged; Case-Control Studies; Nutritional Status; Italy/epidemiology; Odds Ratio; *Diet; Carcinoma, Squamous Cell/etiology/*prevention & control; Dietary Fiber; Esophageal Neoplasms/etiology/*prevention & control; Mediterranean Region; Mouth Neoplasms/etiology/*prevention & control; Olive Oil; Pharyngeal Neoplasms/etiology/*prevention & control; Plant Oils; notion; Aged Carcinoma
Pages: 1091-4
Publication Title: Cancer Epidemiol Biomarkers Prev
Publication Year: 2003
Volume: 12