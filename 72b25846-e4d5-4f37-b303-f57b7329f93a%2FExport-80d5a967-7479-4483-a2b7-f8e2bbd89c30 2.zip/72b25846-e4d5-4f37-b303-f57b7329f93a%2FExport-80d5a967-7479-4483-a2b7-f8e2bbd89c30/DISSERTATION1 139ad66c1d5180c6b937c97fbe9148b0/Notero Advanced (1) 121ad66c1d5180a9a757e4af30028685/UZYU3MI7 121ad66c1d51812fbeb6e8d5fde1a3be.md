# UZYU3MI7

Reading Status: To Find
Title: Improved survival in HPV/p16-positive oropharyngeal cancer patients treated with postoperative radiotherapy
Access Date: 21. Dezember 2023
Author: G, Heiduschka; A, Grah; F, Oberndorfer; L, Kadletz; G, Altorjai; G, Kornek
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 23. April 2024 22:46 (MESZ)
Link Attachments: notion://www.notion.so/G-et-al-o-J-437f4a0faf1343b0a156f16d79735ac2
Manual Tags: notion
Pages: 209-16
Publication Title: Strahlenther Onkol
Publication Year: 0
Volume: 191