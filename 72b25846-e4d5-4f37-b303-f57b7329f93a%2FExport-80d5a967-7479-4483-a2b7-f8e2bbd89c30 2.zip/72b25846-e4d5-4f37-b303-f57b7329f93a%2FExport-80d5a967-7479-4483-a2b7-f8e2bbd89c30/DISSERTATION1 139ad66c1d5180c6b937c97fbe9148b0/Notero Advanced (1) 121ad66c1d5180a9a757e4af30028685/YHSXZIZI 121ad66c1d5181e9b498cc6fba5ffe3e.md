# YHSXZIZI

Reading Status: To Find
Title: Large language models should be used as scientific reasoning engines, not knowledge databases
DOI: 10.1038/s41591-023-02594-z
URL: https://www.nature.com/articles/s41591-023-02594-z
Author: Truhn, Daniel; Reis-Filho, Jorge S; Kather, Jakob Nikolas
Automatic Tags: Biomedical engineering; KI; Diseases; Scientific community
Date: 2023
Date Added: 17. Dezember 2023 20:06 (MEZ)
Date Modified: 14. Mai 2024 11:35 (MESZ)
ISSN: 1546-170X
Issue: 12
Language: en
Link Attachments: notion://www.notion.so/Truhn-et-al-2023-e9309314ab144372b7ec7fbaad3c4d8c
Manual Tags: notion
Pages: 2983-2984
Publication Title: Nature Medicine
Publication Year: 2023
Volume: 29