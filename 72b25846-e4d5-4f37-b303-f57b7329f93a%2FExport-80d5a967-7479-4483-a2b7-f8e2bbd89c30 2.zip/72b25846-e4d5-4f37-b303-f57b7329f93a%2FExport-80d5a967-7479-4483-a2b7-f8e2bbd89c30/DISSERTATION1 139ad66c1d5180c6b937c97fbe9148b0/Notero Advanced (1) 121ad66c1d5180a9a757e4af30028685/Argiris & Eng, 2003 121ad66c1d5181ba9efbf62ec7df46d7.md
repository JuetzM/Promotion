# Argiris & Eng, 2003

Reading Status: To Find
Item Type: Zeitschriftenartikel
Title: Epidemiology, staging, and screening of head and neck cancer
Authors: Argiris, A.
Eng, C.
Year: 2003
DOI: https://doi.org/10/cdpwvj
URL: https://www.ncbi.nlm.nih.gov/pubmed/12619537
Zotero URI: https://zotero.org/mjuetz/items/54L39BVG
Full Citation: <div class="csl-bib-body" style="line-height: 2; margin-left: 2em; text-indent:-2em;">
  <div class="csl-entry">Argiris, A., &amp; Eng, C. (2003). Epidemiology, staging, and screening of head and neck cancer. <i>Cancer Treat Res</i>, <i>114</i>, 15–60. Medline. <a href="https://doi.org/10/cdpwvj">https://doi.org/10/cdpwvj</a>

    <div class="csl-block">titleTranslation: Epidemiologie, Stadieneinteilung und Screening von Kopf- und Halskrebs</div>
</div>
  <span class="Z3988" title="url_ver=Z39.88-2004&amp;ctx_ver=Z39.88-2004&amp;rfr_id=info%3Asid%2Fzotero.org%3A2&amp;rft_id=info%3Adoi%2F10%2Fcdpwvj&amp;rft_val_fmt=info%3Aofi%2Ffmt%3Akev%3Amtx%3Ajournal&amp;rft.genre=article&amp;rft.atitle=Epidemiology%2C%20staging%2C%20and%20screening%20of%20head%20and%20neck%20cancer&amp;rft.jtitle=Cancer%20Treat%20Res&amp;rft.volume=114&amp;rft.aufirst=A.&amp;rft.aulast=Argiris&amp;rft.au=A.%20Argiris&amp;rft.au=C.%20Eng&amp;rft.date=2003&amp;rft.pages=15-60&amp;rft.spage=15&amp;rft.epage=60&amp;rft.issn=0927-3042%20(Print)%200927-3042%20(Linking)&amp;rft.language=eng"></span>
</div>
Collections: exportlist-7
Date: 2003
Date Added: 11. Juli 2024 04:24 (MESZ)
Date Modified: 12. Oktober 2024 21:09 (MESZ)
Extra: titleTranslation: Epidemiologie, Stadieneinteilung und Screening von Kopf- und Halskrebs
Publication: Cancer Treat Res
Tags: *Mass Screening, Disease Susceptibility, Head and Neck Neoplasms/classification/*epidemiology/*pathology, Humans, Neoplasm Staging, Risk Factors, SEER Program