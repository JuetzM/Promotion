# DKT3FLXY

Reading Status: To Find
Title: c-Met expression is a marker of poor prognosis in patients with locally advanced head and neck squamous cell carcinoma treated with chemoradiation
Access Date: 21. Dezember 2023
Author: AM, Baschnagel; L, Williams; A, Hanna; PY, Chen; DJ, Krauss; BL, Pruetz
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:01 (MESZ)
Link Attachments: notion://www.notion.so/AM-et-al-o-J-2bac62dd6ecc4930b005322177a8ccf6
Manual Tags: notion
Pages: 701-7
Publication Title: Int J Radiat Oncol Biol Phys
Publication Year: 0
Volume: 88