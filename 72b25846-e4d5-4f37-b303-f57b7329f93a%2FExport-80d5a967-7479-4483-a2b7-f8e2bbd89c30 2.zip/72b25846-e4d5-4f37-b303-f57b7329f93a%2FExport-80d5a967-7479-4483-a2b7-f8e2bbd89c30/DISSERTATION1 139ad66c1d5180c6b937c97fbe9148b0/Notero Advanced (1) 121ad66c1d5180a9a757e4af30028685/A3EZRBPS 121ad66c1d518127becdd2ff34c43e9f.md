# A3EZRBPS

Reading Status: To Find
Title: Evaluation of quality of life of patients with oral squamous cell carcinoma. Comparison of two treatment protocols in a prospective study
DOI: 10.1016/j.radonc.2003.11.017
URL: https://www.thegreenjournal.com/article/S0167-8140(03)00444-4/abstract
Abstract Note: BACKGROUND AND PURPOSE: In recent years, various therapeutic concepts have been developed for treating oral cancer, these include preoperative simultaneous "neoadjuvant" radio-chemotherapy and one-stage-surgery with tumour ablation and reconstruction. When considering long-term survival, there is substantial evidence that the neoadjuvant therapy is superior to the primary surgical approach with postoperative radiation. Both treatment concepts, however, have a strong impact on the quality of life. PATIENTS AND METHODS: This study prospectively evaluates and compares quality of life in 53 patients with oral cancer treated according to a neoadjuvant concept or primarily surgically, using the questionnaires QLQ C-30 and H and N35 by the EORTC. RESULTS: Initially both groups showed a marked reduction in the quality of life. Despite a clear improvement in the first postoperative year baseline values were not reached in most of the scores. Specific long-lasting impairments in the symptom scales concerning oral functions were found in both treatment arms. In the neoadjuvant therapy group, however, especially global health and the emotional status were reduced to a higher degree than in the other group. This was particularly noticeable in the early treatment phase. CONCLUSIONS: Following an initial deterioration of quality-of-life after 3 months a gradual improvement of physical and psychological function was observed in the course of the first post-treatment year in both groups. Severe side effects can be observed. These side effects vary strongly in their individual expression. Limitations in the quality of life can be justified, if the more aggressive therapy resulted in a better disease free survival.
Author: Kessler, P. A.; Bloch-Birkholz, A.; Leher, A.; Neukam, F. W.; Wiltfang, J.
Date: 2004
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 16. Februar 2024 15:20 (MEZ)
Extra: Type: Journal Article
ISSN: 0167-8140 (Print) 0167-8140 (Linking)
Issue: 3
Link Attachments: notion://www.notion.so/Kessler-et-al-2004-5b023b54fa7d47a197da785f201cc22d
Manual Tags: notion; Adult Aged Carcinoma; Squamous Cell/surgery/*therapy Combined Modality Therapy Female Humans Male Middle Aged Mouth Neoplasms/surgery/*therapy Neoadjuvant Therapy *Quality of Life Surveys and Questionnaires
Pages: 275-82
Publication Title: Radiother Oncol
Publication Year: 2004
Volume: 70