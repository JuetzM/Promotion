# UXLACCT3

Reading Status: To Find
Title: Liposome encapsulated curcumin-difluorinated (CDF) inhibits the growth of cisplatin resistant head and neck cancer stem cells
DOI: 10.18632/oncotarget.4181
Abstract Note: Head and neck squamous cell carcinoma (HNSCC) is the sixth most common cancer, with 600,000 new cases every year worldwide. Although chemotherapeutics exist, five-year survival is only 50%. New strategies to overcome drug resistance are required to improve HNSCC treatment. Curcumin-difluorinated (CDF), a synthetic analog of curcumin, was packaged in liposomes and used to evaluate growth inhibition of cisplatin resistant HNSCC cell lines CCL-23R and UM-SCC-1R generated from the parental cell lines CCL-23 and UM-SCC-1 respectively. Growth inhibition in vitro and expression levels of the CD44 (cancer stem cell marker), cytokines, and growth factors were investigated after liposomal CDF treatment. The in vivo growth inhibitory effect of liposomal CDF was evaluated in the nude mice xenograft tumor model of UM-SCC-1R and the inhibition of CD44 was measured. Treatment of the resistant cell lines in vitro with liposomal CDF resulted in a statistically significant growth inhibition (p < 0.05). The nude mice xenograft study showed a statistically significant tumor growth inhibition of UM-SCC-1R cells and a reduction in the expression of CD44 (p < 0.05), indicating an inhibitory effect of liposomal CDF on CSCs. Our results demonstrate that delivery of CDF through liposomes may be an effective method for the treatment of cisplatin resistant HNSCC.
Author: Basak, Saroj K.; Zinabadi, Alborz; Wu, Arthur W.; Venkatesan, Natarajan; Duarte, Victor M.; Kang, James J.; Dalgard, Clifton L.; Srivastava, Meera; Sarkar, Fazlul H.; Wang, Marilene B.; Srivatsan, Eri S.
Automatic Tags: Female; Humans; Animals; Cell Line, Tumor; Gene Expression Regulation, Neoplastic; Reverse Transcriptase Polymerase Chain Reaction; Drug Resistance, Neoplasm; head and neck cancer; Hyaluronan Receptors; Carcinoma, Squamous Cell; Head and Neck Neoplasms; Antineoplastic Agents; Neoplastic Stem Cells; Mice, Nude; Xenograft Model Antitumor Assays; Tumor Burden; Cell Proliferation; Cisplatin; cancer stem cell (CSC); cisplatin; Curcumin; curcumin-difluorinated (CDF); Cytokines; drug resistance; Hydrocarbons, Fluorinated; Liposomes
Date: 2015-07-30
Date Added: 3. Mai 2024 09:18 (MESZ)
Date Modified: 14. Mai 2024 11:42 (MESZ)
Extra: PMID: 26098778 PMCID: PMC4621906
File Attachments: /Users/martin/Zotero/storage/5NS6K3SX/Basak et al_2015_Liposome encapsulated curcumin-difluorinated (CDF) inhibits the growth of.pdf; ; 
ISSN: 1949-2553
Issue: 21
Journal Abbreviation: Oncotarget
Language: eng
Library Catalog: PubMed
Link Attachments: notion://www.notion.so/Basak-et-al-2015-e5c1bceb19ed42be9ba896fe9c73b64c; http://www.ncbi.nlm.nih.gov/pubmed/26098778
Manual Tags: notion
Pages: 18504-18517
Publication Title: Oncotarget
Publication Year: 2015
Volume: 6