# SHY2TK2X

Reading Status: To Find
Title: Laser debulking in malignant upper airway obstruction
DOI: 10.1002/hed.20153
URL: https://onlinelibrary.wiley.com/doi/10.1002/hed.20153
Abstract Note: BACKGROUND: The conventional treatment for patients with upper airway obstruction secondary to malignancy is a tracheostomy. Although this effectively resolves the problem, a tracheostomy can be associated with complications and is irreversible in most patients. An alternative is to debulk part of the tumor causing airway obstruction to maintain the airway until the definitive procedure. METHODS: The clinical course of 43 patients who underwent laser debulking for airway obstruction caused by laryngeal or hypopharyngeal malignancies was retrospectively studied. We present our technique of laser debulking and the efficacy of the procedure in avoiding a tracheostomy. RESULTS: Fourteen patients who underwent this procedure received palliative treatment only. The number of debulking procedures per patient ranged from one to six, with a mean of 1.9 episodes. Although these patients had a higher comorbid burden, none were thought unsuitable for the procedure. A tracheostomy was avoided in 91% of patients. No laser-related complications were encountered. CONCLUSIONS: Laser debulking is a viable alternative to tracheostomy in patients with malignant upper airway obstruction.
Author: Paleri, V.; Stafford, F. W.; Sammut, M. S.
Date: 2005
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:25 (MEZ)
Extra: Type: Journal Article
ISSN: 1043-3074 (Print) 1043-3074 (Linking)
Issue: 4
Link Attachments: notion://www.notion.so/Paleri-et-al-2005-399a6f64bf414c068aa18f3fc75b6b9c
Manual Tags: Female; Humans; Male; Middle Aged; Aged; Aged, 80 and over; Retrospective Studies; Follow-Up Studies; Palliative Care; notion; Neoplasm Invasiveness; Airway Obstruction/etiology/*surgery; Hemostasis, Surgical; Hypopharyngeal Neoplasms/complications/*surgery; Laryngeal Neoplasms/complications/*surgery; Laryngoscopy; Laser Therapy/*methods; Respiratory Sounds/etiology; Tracheostomy; Aged Aged; 80 and over Airway Obstruction/etiology/*surgery Female Follow-Up Studies Hemostasis
Pages: 296-301
Publication Title: Head Neck
Publication Year: 2005
Volume: 27