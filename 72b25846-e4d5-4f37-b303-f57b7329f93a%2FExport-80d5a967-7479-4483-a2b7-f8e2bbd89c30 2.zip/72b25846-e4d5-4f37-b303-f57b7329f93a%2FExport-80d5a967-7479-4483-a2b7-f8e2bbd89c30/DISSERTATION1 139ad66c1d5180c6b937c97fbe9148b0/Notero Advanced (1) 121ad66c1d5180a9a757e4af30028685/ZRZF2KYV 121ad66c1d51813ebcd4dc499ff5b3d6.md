# ZRZF2KYV

Reading Status: To Find
Title: The EORTC randomized trial on three fractions per day and misonidazole in advanced head and neck cancer: prognostic factors
Access Date: 21. Dezember 2023
Author: Bogaert, W. van den; Schueren, E. van der; Horiot, J.C.; Vilhena, M. De; al., et
Date: 1995
Date Added: 21. Dezember 2023 09:11 (MEZ)
Date Modified: 23. April 2024 22:48 (MESZ)
Link Attachments: notion://www.notion.so/Bogaert-et-al-1995-eed4de7aa4a94fd3bdc159bab7876446
Manual Tags: notion
Pages: 100-106
Publication Title: Radiother Oncol
Publication Year: 1995
Volume: 35