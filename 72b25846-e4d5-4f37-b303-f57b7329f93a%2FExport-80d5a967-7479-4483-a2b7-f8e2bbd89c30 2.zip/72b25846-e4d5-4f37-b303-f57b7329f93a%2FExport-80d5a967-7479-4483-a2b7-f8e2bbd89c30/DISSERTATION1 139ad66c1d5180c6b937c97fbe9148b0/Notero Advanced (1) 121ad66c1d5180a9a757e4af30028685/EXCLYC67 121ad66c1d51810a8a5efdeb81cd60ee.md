# EXCLYC67

Reading Status: To Find
Title: Head and neck cancer in the betel quid chewing area: recent advances in molecular carcinogenesis
DOI: 10.1111/j.1349-7006.2008.00863.x
URL: https://www.ncbi.nlm.nih.gov/pubmed/18754860
Abstract Note: Head and neck cancer (HNC) is one of the 10 most frequent cancers worldwide, with an estimated over 500,000 new cases being diagnosed annually. The overall 5-year survival rate in patients with HNC is one of the lowest among common malignant neoplasms and has not significantly changed during the last two decades. Oral cavity squamous cell carcinoma (OSCC) shares part of HNC and has been reported to be increasing in the betel quid chewing area in recent years. During 2006, OSCC has become the sixth most common type of cancer in Taiwan, and it is also the fourth most common type of cancer among men. It follows that this type of cancer wreaks a high social and personal cost. Environmental carcinogens such as betel quid chewing, tobacco smoking and alcohol drinking have been identified as major risk factors for head and neck cancer. There is growing interest in understanding the relationship between genetic susceptibility and the prevalent environmental carcinogens for HNC prevention. Within this review, we discuss the molecular and cellular aspects of HNC carcinogenesis in Taiwan, an endemic betel quid chewing area. Knowledge of molecular carcinogenesis of HNC may provide critical clues for diagnosis, prognosis, individualization of therapy and molecular therapeutics.
Author: Chen, Y. J.; Chang, J. T.; Liao, C. T.; Wang, H. M.; Yen, T. C.; Chiu, C. C.; Lu, Y. C.; Li, H. F.; Cheng, A. J.
Automatic Tags: Taiwan; Alcohol Drinking; Smoking; Carcinoma, Squamous Cell; Head and Neck Neoplasms; Papillomavirus Infections; Mouth Neoplasms; Areca; Precancerous Conditions
Date: 2008
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:24 (MEZ)
Extra: Type: Journal Article
File Attachments: ; 
ISSN: 1349-7006 (Electronic) 1347-9032 (Linking)
Issue: 8
Link Attachments: notion://www.notion.so/Chen-et-al-2008-1ac5325448ec4e4b9cae11d4132465d4; http://www.ncbi.nlm.nih.gov/pubmed/18754860
Manual Tags: Female; Humans; Male; Middle Aged; Risk Factors; Adult; Survival Analysis; Alcohol Drinking/adverse effects; Genetic Predisposition to Disease; Smoking/adverse effects; Areca/*adverse effects; Carcinoma, Squamous Cell/etiology/*genetics/metabolism; Head and Neck Neoplasms/*etiology/genetics/metabolism; Mouth Neoplasms/etiology/genetics/metabolism; Mutation; Papillomavirus Infections/*complications; Polymorphism, Genetic; Precancerous Conditions/etiology/*genetics/metabolism; Taiwan/epidemiology; notion; Adult Alcohol Drinking/adverse effects Areca/*adverse effects Carcinoma; Genetic Precancerous Conditions/etiology/*genetics/metabolism Risk Factors Smoking/adverse effects Survival Analysis Taiwan/epidemiology
Pages: 1507-14
Publication Title: Cancer Sci
Publication Year: 2008
Volume: 99