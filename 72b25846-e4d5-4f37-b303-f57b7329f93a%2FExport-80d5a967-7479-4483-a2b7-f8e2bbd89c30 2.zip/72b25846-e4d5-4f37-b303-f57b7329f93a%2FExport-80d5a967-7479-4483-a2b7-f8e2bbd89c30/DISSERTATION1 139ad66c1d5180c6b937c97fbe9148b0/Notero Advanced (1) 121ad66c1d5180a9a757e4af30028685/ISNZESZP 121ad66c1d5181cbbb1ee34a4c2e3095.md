# ISNZESZP

Reading Status: To Find
Title: HPV-associated head and neck cancer: a virus-related cancer epidemic
DOI: 10.1016/S1470-2045(10)70017-6
URL: https://www.ncbi.nlm.nih.gov/pubmed/20451455
Abstract Note: A rise in incidence of oropharyngeal squamous cell cancer–specifically of the lingual and palatine tonsils–in white men younger than age 50 years who have no history of alcohol or tobacco use has been recorded over the past decade. This malignant disease is associated with human papillomavirus (HPV) 16 infection. The biology of HPV-positive oropharyngeal cancer is distinct with P53 degradation, retinoblastoma RB pathway inactivation, and P16 upregulation. By contrast, tobacco-related oropharyngeal cancer is characterised by TP53 mutation and downregulation of CDKN2A (encoding P16). The best method to detect virus in tumour is controversial, and both in-situ hybridisation and PCR are commonly used; P16 immunohistochemistry could serve as a potential surrogate marker. HPV-positive oropharyngeal cancer seems to be more responsive to chemotherapy and radiation than HPV-negative disease. HPV 16 is a prognostic marker for enhanced overall and disease-free survival, but its use as a predictive marker has not yet been proven. Many questions about the natural history of oral HPV infection remain under investigation. For example, why does the increase in HPV-related oropharyngeal cancer dominate in men? What is the potential of HPV vaccines for primary prevention? Could an accurate method to detect HPV in tumour be developed? Which treatment strategies reduce toxic effects without compromising survival? Our aim with this review is to highlight current understanding of the epidemiology, biology, detection, and management of HPV-related oropharyngeal head and neck squamous cell carcinoma, and to describe unresolved issues.
Author: Marur, S.; D'Souza, G.; Westra, W. H.; Forastiere, A. A.
Automatic Tags: Carcinoma, Squamous Cell; Tumor Virus Infections; Human papillomavirus 16; Papillomavirus Infections; Oropharyngeal Neoplasms
Date: 2010
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:24 (MEZ)
Extra: Type: Journal Article
File Attachments: /Users/martin/Zotero/storage/M27W38Z9/Marur et al. - 2010 - HPV-associated head and neck cancer a virus-relat.pdf; ; 
ISSN: 1474-5488 (Electronic) 1470-2045 (Print) 1470-2045 (Linking)
Issue: 8
Link Attachments: notion://www.notion.so/Marur-et-al-2010-f526d8e9d5f4419c902ad8a2f992af66; http://www.ncbi.nlm.nih.gov/pubmed/20451455
Manual Tags: *Human papillomavirus 16/isolation & purification; Biomarkers, Tumor; Carcinoma, Squamous Cell/epidemiology/pathology/therapy/*virology; Female; Humans; In Situ Hybridization; Incidence; Male; Middle Aged; Oropharyngeal Neoplasms/epidemiology/pathology/therapy/*virology; Papillomavirus Infections/*complications/virology; Polymerase Chain Reaction; Risk Factors; Sex Distribution; Survival Rate; Tumor Virus Infections/*complications/virology; notion; Biomarkers; Tumor Carcinoma
Pages: 781-9
Publication Title: Lancet Oncol
Publication Year: 2010
Volume: 11