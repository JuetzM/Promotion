# 34R4XZRW

Reading Status: To Find
Title: [Metastases of unknown origin–principles of diagnosis and treatment]
DOI: 10.2298/mpns0702029p
URL: https://doiserbia.nb.rs/Article.aspx?ID=0025-81050702029P
Abstract Note: DEFINITION: Cancer of unknown primary (CUP) origin refers to patients who present with histologicaly confirmed metastatic cancer in whom a detailed medical history, complete physical examination, including pelvic and rectal examination, full blood count and biochemistry, urinalysis and stool occult blood testing, hisinpathological review oJ biopsy speimens with the use of immunohistochemistry, chest radiography, computed tomography of the abdomen and pelvis, and in certain cases mammography, fail to identify the primary site. EPIDEMIOLOGY OF CUP: The cancer of unknown primary accounts for 3%-5% of all human cancers. DIAGNOSIS OF CUP: The standard diagnostic procedure for the majority of patients includes histopathologic review of biopsy specimens with the use of immunoltistochemistry, chest radiography, computed tomography of the abdomen and pelvis, and in certain cases mamography, fail to identify the abdomen and pelvis. The four common histologic diagnoses are: adenocarcinoma (70%), poorly differentiated carcinoma (20%), squamous carcinoma (10%), and poorly differentiated neoplasms (5%). PROGNOSIS OF CUP: The prognosis for most patients with unknown primary tumors is poor, with survival often less than 6 months from diagnosis. THERAPY OF CUP: Based on clinical and pathologic features, approximately 40% of patients can be categorized within subsets for which specific treatment has been defined. Empiric therapy is an option for the remaining 60% of patients. CONCLUSION: Metastatic tumors of unknown origin have a unique clinical presentation due to a specific biology. Insight into the molecular biology of unknown primary tumors will be essential for the development of more effective treatments.
Author: Petrovic, D.; Muzikravic, L.; Jovanovic, D.
Date: 2007
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 16. Februar 2024 15:23 (MEZ)
Extra: Type: Journal Article
ISSN: 0025-8105 (Print) 0025-8105 (Linking)
Issue: 1-2
Link Attachments: notion://www.notion.so/Petrovic-et-al-2007-cf43f43284a246209cc3d480dbcc07bd
Manual Tags: notion; Humans Neoplasm Metastasis/*diagnosis/*therapy Neoplasms; Unknown Primary/*diagnosis/therapy
Pages: 29-36
Publication Title: Med Pregl
Publication Year: 2007
Volume: 60