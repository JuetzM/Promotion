# QGIUPCZS

Reading Status: To Find
Title: Meta-analysis of chemotherapy in head and neck cancer (MACH-NC): an update on 93 randomised trials and 17,346 patients
DOI: 10.1016/j.radonc.2009.04.014
URL: https://www.thegreenjournal.com/article/S0167-8140(09)00188-1/abstract
Abstract Note: BACKGROUND: Our previous individual patient data (IPD) meta-analysis showed that chemotherapy improved survival in patients curatively treated for non-metastatic head and neck squamous cell carcinoma (HNSCC), with a higher benefit with concomitant chemotherapy. However the heterogeneity of the results limited the conclusions and prompted us to confirm the results on a more complete database by adding the randomised trials conducted between 1994 and 2000. METHODS: The updated IPD meta-analysis included trials comparing loco-regional treatment to loco-regional treatment+chemotherapy in HNSCC patients and conducted between 1965 and 2000. The log-rank-test, stratified by trial, was used to compare treatments. The hazard ratios of death were calculated. RESULTS: Twenty-four new trials, most of them of concomitant chemotherapy, were included with a total of 87 trials and 16,485 patients. The hazard ratio of death was 0.88 (p<0.0001) with an absolute benefit for chemotherapy of 4.5% at 5 years, and a significant interaction (p<0.0001) between chemotherapy timing (adjuvant, induction or concomitant) and treatment. Both direct (6 trials) and indirect comparisons showed a more pronounced benefit of the concomitant chemotherapy as compared to induction chemotherapy. For the 50 concomitant trials, the hazard ratio was 0.81 (p<0.0001) and the absolute benefit 6.5% at 5 years. There was a decreasing effect of chemotherapy with age (p=0.003, test for trend). CONCLUSION: The benefit of concomitant chemotherapy was confirmed and was greater than the benefit of induction chemotherapy.
Author: Pignon, J. P.; le Maitre, A.; Maillard, E.; Bourhis, J.; Group, Mach-Nc Collaborative
Automatic Tags: Carcinoma, Squamous Cell; Head and Neck Neoplasms; Antineoplastic Agents; Meta-Analysis as Topic
Date: 2009
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:25 (MEZ)
Extra: Type: Journal Article
File Attachments: ; 
ISSN: 1879-0887 (Electronic) 0167-8140 (Linking)
Issue: 1
Link Attachments: notion://www.notion.so/Pignon-et-al-2009-e19f82db979a4b63b18b571219546a63; http://www.ncbi.nlm.nih.gov/pubmed/19446902
Manual Tags: Humans; Combined Modality Therapy; Treatment Outcome; Antineoplastic Agents/*therapeutic use; Randomized Controlled Trials as Topic; notion; *Meta-Analysis as Topic; Carcinoma, Squamous Cell/*drug therapy/radiotherapy; Head and Neck Neoplasms/*drug therapy/radiotherapy; Antineoplastic Agents/*therapeutic use Carcinoma; Squamous Cell/*drug therapy/radiotherapy Combined Modality Therapy Head and Neck Neoplasms/*drug therapy/radiotherapy Humans *Meta-Analysis as Topic Randomized Controlled Trials as Topic Treatment Outcome
Pages: 4-14
Publication Title: Radiother Oncol
Publication Year: 2009
Volume: 92