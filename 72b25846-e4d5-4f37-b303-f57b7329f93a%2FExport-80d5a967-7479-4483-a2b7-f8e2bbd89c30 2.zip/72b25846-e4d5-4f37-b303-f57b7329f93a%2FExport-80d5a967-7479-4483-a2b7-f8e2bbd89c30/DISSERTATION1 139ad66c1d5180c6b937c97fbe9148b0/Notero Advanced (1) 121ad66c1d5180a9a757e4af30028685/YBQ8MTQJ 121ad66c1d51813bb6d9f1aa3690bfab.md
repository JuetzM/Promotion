# YBQ8MTQJ

Reading Status: To Find
Title: Incidence and sites of distant metastases from head and neck cancer
DOI: 10.1159/000055740
URL: https://karger.com/orl/article-abstract/63/4/202/260848/Incidence-and-Sites-of-Distant-Metastases-from?redirectedFrom=fulltext
Abstract Note: The incidence of distant metastases in head and neck squamous cell carcinoma (SCC) is relatively small in comparison to other malignancies. Distant metastases adversely impact survival and may significantly affect treatment planning. The incidence of distant metastases is influenced by location of the primary tumor, initial T and N stage of the neoplasm, and the presence or absence of regional control above the clavicle. Patients with advanced nodal disease have a high incidence of distant metastases, particularly in the presence of jugular vein invasion or extensive soft tissue disease in the neck. Primary tumors of advanced T stages in the hypopharynx, oropharynx and oral cavity are associated with the highest incidence of distant metastases. Pulmonary metastases are the most frequent in SCC, accounting for 66% of distant metastases. It may be difficult to distinguish pulmonary metastasis from a new primary tumor, particularly if solitary. Other metastatic sites include bone (22%), liver (10%), skin, mediastinum and bone marrow. An important question remains as to how intensely pre- and postoperative screening for distant metastases should be performed. Preoperative chest X-ray is warranted in all cases. If the primary tumor and nodal status place the patient at high risk for pulmonary metastasis, then preoperative computed tomography scan of the chest should be done. Screening for distant metastases at other sites is usually not indicated in SCC of the upper aerodigestive tract. Postoperatively, annual X-rays of the chest are usually sufficient, but in high-risk situations a chest X-ray performed every 3-6 months may be beneficial. Certain histologic types of primary tumor have greater or lesser propensity to metastasize distantly, and have a different natural history. Adenoid cystic carcinoma metastasizes frequently, even in the absence of extensive local or regional disease. Basaloid squamous cell carcinoma and neuroendocrine carcinomas also metastasize widely. Extensive evaluation for distant metastases is justified for these tumors. Knowledge of the natural history of various neoplasms and the factors that contribute to distant metastases as well as good judgement are essential for cost-effective treatment planning and decision-making with regard to pre- and postoperative evaluation for distant metastases in cancer of the head and neck.
Author: Ferlito, A.; Shaha, A. R.; Silver, C. E.; Rinaldo, A.; Mondin, V.
Automatic Tags: Carcinoma; Bone Neoplasms; Liver Neoplasms; Lung Neoplasms; Head and Neck Neoplasms; Neoplasms, Second Primary
Date: 2001
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 29. Februar 2024 15:24 (MEZ)
Extra: Type: Journal Article
File Attachments: ; 
ISSN: 0301-1569 (Print) 0301-1569 (Linking)
Issue: 4
Link Attachments: notion://www.notion.so/Ferlito-et-al-2001-cfe09e4ad12a441b9d932de1e0975485; http://www.ncbi.nlm.nih.gov/pubmed/11408812
Manual Tags: Humans; Incidence; Neoplasm Staging; Head and Neck Neoplasms/*pathology; Bone Neoplasms/epidemiology/*secondary; Carcinoma/epidemiology/*secondary; Liver Neoplasms/epidemiology/*secondary; Lung Neoplasms/epidemiology/*secondary; Neoplasms, Second Primary/epidemiology; Neoplastic Cells, Circulating; notion; Bone Neoplasms/epidemiology/*secondary Carcinoma/epidemiology/*secondary Head and Neck Neoplasms/*pathology Humans Incidence Liver Neoplasms/epidemiology/*secondary Lung Neoplasms/epidemiology/*secondary Neoplasm Staging Neoplasms; Circulating; Second Primary/epidemiology Neoplastic Cells
Pages: 202-7
Publication Title: ORL J Otorhinolaryngol Relat Spec
Publication Year: 2001
Volume: 63