# Book Chapter Template

Reading Status: To Find

# Annotated Bibliography Entry

<aside>
📌 How is this chapter relevant to your research? Who is it useful for?

</aside>

---

# Reactions & Questions

- What aspects of this chapter did you like or appreciate (and perhaps want to incorporate in your own work)?
- What aspects of this chapter did you dislike (and perhaps want to avoid in your own work)?
- Did anything about this chapter surprise you?
- What aspects of this chapter confused you? What questions do you still have?

---

# Relevance to My Work

- How is this source helpful for understanding my research topic?
    - Do the study’s findings support or contradict my research?
    - Does the paper report statistics or offer strong arguments that are useful for justifying why my research topic is important?
    - Does this paper help us identify a gap in the literature that I can help answer with my dataset?
    - Did the paper make you think about your topic in a new way? Did it pose new questions you haven’t considered yet?
- How does this source connect with other works you have read? Place two or more studies in conversation. Where are their resonances and tensions? What gaps and lingering questions remain to be addressed? How do those works help you advance your own project?
    - [ ]  👉 Remember to link to related pages in Notion and the **parent book**

---

# Chapter Summary

- What problem is the researcher trying to understand? What are the objectives or aims of the study?
    - What specific hypotheses or research questions does the chapter address? What questions do you wish they had asked?
- Why is it important to research this topic? Why should we care?
- How did the authors test the hypothesis or investigate the research question(s)?
- What are the authors’ major findings?
    - What evidence supports their interpretations?
    - Do their conclusions seem logical given the data presented? Why or why not?
    - Why are the findings of this research important?
- What are the limitations or weaknesses of the research study?
- What are the next steps or future directions for this research?

# Promising References