# X96HR6VC

Reading Status: To Find
Title: Six ways large language models are changing healthcare
DOI: 10.1038/s41591-023-02700-1
URL: https://www.nature.com/articles/s41591-023-02700-1
Abstract Note: Nature Medicine asks six leading AI researchers to explain how LLM-powered chatbots are having an impact on health, from virtual nurses to detecting cancer progression.
Author: Webster, Paul
Automatic Tags: KI; general; Neurosciences; Biomedicine; Cancer Research; Infectious Diseases; Metabolic Diseases; Molecular Medicine
Date: 2023
Date Added: 17. Dezember 2023 20:06 (MEZ)
Date Modified: 14. Mai 2024 11:35 (MESZ)
ISSN: 1546-170X
Issue: 12
Language: en
Link Attachments: notion://www.notion.so/Webster-2023-1bd6cf78747e4393b8e6e192f0610abe
Manual Tags: notion
Pages: 2969-2971
Publication Title: Nature Medicine
Publication Year: 2023
Volume: 29