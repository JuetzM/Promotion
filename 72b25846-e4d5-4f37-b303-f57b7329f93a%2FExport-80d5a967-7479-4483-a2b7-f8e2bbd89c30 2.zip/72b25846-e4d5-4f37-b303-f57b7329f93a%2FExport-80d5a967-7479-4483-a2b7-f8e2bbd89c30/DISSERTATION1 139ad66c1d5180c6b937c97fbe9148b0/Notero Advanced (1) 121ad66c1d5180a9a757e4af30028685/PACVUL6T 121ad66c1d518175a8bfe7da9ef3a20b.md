# PACVUL6T

Reading Status: To Find
Title: Tumor progression in waiting time for radiotherapy in head and neck cancer
Access Date: 21. Dezember 2023
Author: Jensen, A.R.; Nellemann, H.M.; Overgaard, J.
Date: 2007
Date Added: 21. Dezember 2023 09:11 (MEZ)
Date Modified: 23. April 2024 22:48 (MESZ)
Link Attachments: notion://www.notion.so/Jensen-et-al-2007-389bdc17c14540ecbcd9875f9bbfccd2
Manual Tags: notion
Pages: 5-10
Publication Title: Radiother Oncol
Publication Year: 2007
Volume: 84