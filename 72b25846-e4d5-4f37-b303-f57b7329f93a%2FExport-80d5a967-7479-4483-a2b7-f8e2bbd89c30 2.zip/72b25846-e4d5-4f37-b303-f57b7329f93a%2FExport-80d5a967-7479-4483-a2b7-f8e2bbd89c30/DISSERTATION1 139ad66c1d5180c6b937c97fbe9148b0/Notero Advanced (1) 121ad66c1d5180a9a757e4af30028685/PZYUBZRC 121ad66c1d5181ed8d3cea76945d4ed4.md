# PZYUBZRC

Reading Status: To Find
Title: Low cancer stem cell marker expression and low hypoxia identify good prognosis subgroups in HPV(-) HNSCC after postoperative radiochemotherapy: A multicenter study of the DKTK-ROG
DOI: 10.1158/1078-0432.CCR-15-1990/128560/AM/LOW-CSC-MARKER-EXPRESSION-AND-LOW-HYPOXIA-IDENTIFY
URL: https://dx.doi.org/10.1158/1078-0432.CCR-15-1990
Abstract Note: Purpose: To investigate the impact of hypoxia-induced gene expression and cancer stem cell (CSC) marker expression on outcome of postoperative cisplatin-based radiochemotherapy (PORT-C) in patients with locally advanced head and neck squamous cell carcinoma (HNSCC). Experimental Design: Expression of the CSC markers CD44, MET, and SLC3A2, and hypoxia gene signatures were analyzed in the resected primary tumors using RT-PCR and nanoString technology in a multicenter retrospective cohort of 195 patients. CD44 protein expression was further analyzed in tissue microarrays. Primary endpoint was locoregional tumor control. Results: Univariate analysis showed that hypoxia-induced gene expression was significantly associated with a high risk of locoregional recurrence using the 15-gene signature (P = 0.010) or the 26-gene signature (P = 0.002). In multivariate analyses, in patients with HPV16 DNA-negative but not with HPV16 DNA-positive tumors the effect of hypoxia-induced genes on locoregional control was apparent (15-gene signature: HR 4.54, P=0.006; 26-gene signature: HR 10.27, P=0.024). Furthermore, MET, SLC3A2, CD44, and CD44 protein showed an association with locoregional tumor control in multivariate analyses (MET: HR 3.71, P = 0.016; SLC3A2: HR 8.54, P = 0.037; CD44: HR 3.36, P = 0.054; CD44 protein n/a because of no event in the CD44-negative group) in the HPV16 DNA-negative subgroup. Conclusions: We have shown for the first time that high hypoxia-induced gene expression and high CSC marker expression levels correlate with tumor recurrence after PORT-C in patients with HPV16 DNA-negative HNSCC. After validation in a currently ongoing prospective trial, these parameters may help to further stratify patients for individualized treatment de-escalation or intensification strategies.
Access Date: 21. Dezember 2023
Author: Linge, Annett; Lock, Steffen; Gudziol, Volker; Nowak, Alexander; Lohaus, Fabian; Von Neubeck, Clare; Jutz, Martin; Abdollahi, Amir; Debus, Jurgen; Tinhofer, Inge; Budach, Volker; Sak, Ali; Stuschke, Martin; Balermpas, Panagiotis; Rodel, Claus; Avlar, Melanie; Grosu, Anca Ligia; Bayer, Christine; Belka, Claus; Pigorsch, Steffi; Combs, Stephanie E.; Welz, Stefan; Zips, Daniel; Buchholz, Frank; Aust, Daniela E.; Baretton, Gustavo B.; Thames, Howard D.; Dubrovska, Anna; Alsner, Jan; Overgaard, Jens; Baumann, Michael; Krause, Mechthild
Date: 2016-06-01
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 29. Februar 2024 15:27 (MEZ)
Extra: PMID: 26755529 Publisher: American Association for Cancer Research Inc.
File Attachments: ; /Users/martin/Zotero/storage/M4839K84/full-text.pdf; /Users/martin/Zotero/storage/S7DDJUJV/Linge et al. - 2016 - Low Cancer Stem Cell Marker Expression and Low Hyp.pdf
ISSN: 15573265
Issue: 11
Link Attachments: notion://www.notion.so/Linge-et-al-2016-52036ac29cf04e81bc990a2a5323ba01
Manual Tags: Humans; Prognosis; Multivariate Analysis; Treatment Outcome; Prospective Studies; Antineoplastic Agents/therapeutic use; Cisplatin/therapeutic use; Kaplan-Meier Estimate; Biomarkers, Tumor/metabolism; Hyaluronan Receptors/metabolism; notion; Chemoradiotherapy; Neoplastic Stem Cells/*metabolism; Carcinoma, Squamous Cell/*metabolism/mortality/pathology/therapy; Cell Hypoxia; Fusion Regulatory Protein 1, Heavy Chain/metabolism; Human papillomavirus 16/genetics; Mouth Neoplasms/*metabolism/mortality/pathology/therapy; Papillomavirus Infections/diagnosis; Transcriptome; Tumor/metabolism Carcinoma; Antineoplastic Agents/therapeutic use Biomarkers; Squamous Cell/*metabolism/mortality/pathology/therapy Cell Hypoxia Chemoradiotherapy Cisplatin/therapeutic use Fusion Regulatory Protein 1
Pages: 2639-2649
Publication Title: Clinical Cancer Research
Publication Year: 2016
Rights: All rights reserved
Volume: 22