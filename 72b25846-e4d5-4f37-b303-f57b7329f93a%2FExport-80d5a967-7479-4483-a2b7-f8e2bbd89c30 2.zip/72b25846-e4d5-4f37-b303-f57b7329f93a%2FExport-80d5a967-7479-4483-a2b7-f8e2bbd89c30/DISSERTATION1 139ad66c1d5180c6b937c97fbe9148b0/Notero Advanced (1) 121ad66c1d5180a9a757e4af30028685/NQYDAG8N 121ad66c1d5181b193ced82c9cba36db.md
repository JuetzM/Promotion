# NQYDAG8N

Reading Status: To Find
Title: Critical evaluation of diagnostic aids for the detection of oral cancer
DOI: 10.1016/j.oraloncology.2007.06.011
URL: https://www.ncbi.nlm.nih.gov/pubmed/17825602
Abstract Note: Historically, the screening of patients for signs of oral cancer and precancerous lesions has relied upon the conventional oral examination. A variety of commercial diagnostic aids and adjunctive techniques are available to potentially assist in the screening of healthy patients for evidence of otherwise occult cancerous change or to assess the biologic potential of clinically abnormal mucosal lesions. This manuscript systematically and critically examines the literature associated with current oral cancer screening and case-finding aids or adjuncts such as toluidine blue, brush cytology, tissue reflectance and autofluorescence. The characteristics of an ideal screening test are outlined and the authors pose several questions for clinicians and scientists to consider in the evaluation of current and future studies of oral cancer detection and diagnosis. Although the increased public awareness of oral cancer made possible by the marketing of recently-introduced screening adjuncts is commendable, the tantalizing implication that such technologies may improve detection of oral cancers and precancers beyond conventional oral examination alone has yet to be rigorously confirmed.
Author: Lingen, M. W.; Kalmar, J. R.; Karrison, T.; Speight, P. M.
Date: 2008
Date Added: 16. Februar 2024 14:54 (MEZ)
Date Modified: 16. Februar 2024 15:20 (MEZ)
Extra: Type: Journal Article
File Attachments: /Users/martin/Zotero/storage/PCTFG2ZG/Lingen et al. - 2008 - Critical evaluation of diagnostic aids for the det.pdf; 
ISSN: 1368-8375 (Print) 1368-8375 (Linking)
Issue: 1
Link Attachments: notion://www.notion.so/Lingen-et-al-2008-44e1b3f9770d46c88d35a6ce13207ad4
Manual Tags: notion; Coloring Agents Cytological Techniques Fluorescence Humans Mass Screening/*methods Mouth Neoplasms/*diagnosis Precancerous Conditions/*diagnosis Spectrophotometry/methods Tolonium Chloride
Pages: 10-22
Publication Title: Oral Oncol
Publication Year: 2008
Volume: 44