# S6P6Y5SH

Reading Status: To Find
Title: Cancer stem cell enrichment marker CD98: a prognostic factor for survival in patients with human papillomavirus-positive oropharyngeal cancer
Access Date: 21. Dezember 2023
Author: MM, Rietbergen; SR, Martens-de Kemp; E, Bloemena; BI, Witte; A, Brink; RJ, Baatenburg de Jong
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:05 (MESZ)
Link Attachments: notion://www.notion.so/MM-et-al-o-J-75ce3c0834c24b32af090eba84cceb93
Manual Tags: notion
Pages: 765-73
Publication Title: Eur J Cancer
Publication Year: 0
Volume: 50