# RZPZAQIF

Reading Status: To Find
Title: FAZA PET/CT hypoxia imaging in patients with squamous cell carcinoma of the head and neck treated with radiotherapy: results from the DAHANCA 24 trial
Access Date: 21. Dezember 2023
Author: LS, Mortensen; J, Johansen; J, Kallehauge; H, Primdahl; M, Busk; P, Lassen
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:23 (MESZ)
Link Attachments: notion://www.notion.so/LS-et-al-o-J-2184f1b086af4373a3b612f8b30c046b
Manual Tags: notion
Pages: 14-20
Publication Title: Radiother Oncol
Publication Year: 0
Volume: 105