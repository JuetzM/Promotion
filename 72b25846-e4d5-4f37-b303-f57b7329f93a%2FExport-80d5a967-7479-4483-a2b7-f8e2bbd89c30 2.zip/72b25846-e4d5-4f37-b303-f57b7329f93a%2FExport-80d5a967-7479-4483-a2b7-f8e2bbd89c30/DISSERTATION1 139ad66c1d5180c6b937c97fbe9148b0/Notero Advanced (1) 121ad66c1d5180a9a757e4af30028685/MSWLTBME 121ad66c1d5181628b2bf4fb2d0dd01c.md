# MSWLTBME

Reading Status: To Find
Title: Direct multiplexed measurement of gene expression with color-coded probe pairs
DOI: 10.1038/NBT1385
Abstract Note: We describe a technology, the NanoString nCounter gene expression system, which captures and counts individual mRNA transcripts. Advantages over existing platforms include direct measurement of mRNA expression levels without enzymatic reactions or bias, sensitivity coupled with high multiplex capability, and digital readout. Experiments performed on 509 human genes yielded a replicate correlation coefficient of 0.999, a detection limit between 0.1 fM and 0.5 fM, and a linear dynamic range of over 500-fold. Comparison of the NanoString nCounter gene expression system with microarrays and TaqMan PCR demonstrated that the nCounter system is more sensitive than microarrays and similar in sensitivity to real-time PCR. Finally, a comparison of transcript levels for 21 genes across seven samples measured by the nCounter system and SYBR Green real-time PCR demonstrated similar patterns of gene expression at all transcript levels. © 2008 Nature Publishing Group.
Access Date: 21. Dezember 2023
Author: Geiss, Gary K.; Bumgarner, Roger E.; Birditt, Brian; Dahl, Timothy; Dowidar, Naeem; Dunaway, Dwayne L.; Fell, H. Perry; Ferree, Sean; George, Renee D.; Grogan, Tammy; James, Jeffrey J.; Maysuria, Malini; Mitton, Jeffrey D.; Oliveri, Paola; Osborn, Jennifer L.; Peng, Tao; Ratcliffe, Amber L.; Webster, Philippa J.; Davidson, Eric H.; Hood, Leroy
Date: 2008-03
Date Added: 21. Dezember 2023 09:17 (MEZ)
Date Modified: 20. April 2024 11:19 (MESZ)
Extra: 1648 citations (Crossref) [2023-12-21] PMID: 18278033
File Attachments: /Users/martin/Zotero/storage/6G8Z5ZSC/Geiss et al. - 2008 - Direct multiplexed measurement of gene expression .pdf; 
ISSN: 10870156
Issue: 3
Link Attachments: notion://www.notion.so/Geiss-et-al-2008-c77987d4757f4f76ab7611a12d928dfb
Manual Tags: notion
Pages: 317-325
Publication Title: Nature Biotechnology
Publication Year: 2008
Volume: 26