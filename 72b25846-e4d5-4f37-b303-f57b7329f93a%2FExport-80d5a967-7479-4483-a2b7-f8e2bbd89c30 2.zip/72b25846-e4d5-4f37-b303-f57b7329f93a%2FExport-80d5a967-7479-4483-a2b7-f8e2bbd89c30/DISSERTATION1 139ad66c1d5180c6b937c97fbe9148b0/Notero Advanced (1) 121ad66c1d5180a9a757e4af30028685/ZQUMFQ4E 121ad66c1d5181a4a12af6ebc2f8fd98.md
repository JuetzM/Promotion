# ZQUMFQ4E

Reading Status: To Find
Title: Targeting cancer stem cell pathways for cancer therapy
DOI: 10.1038/s41392-020-0110-5
Abstract Note: Since cancer stem cells (CSCs) were first identified in leukemia in 1994, they have been considered promising therapeutic targets for cancer therapy. These cells have self-renewal capacity and differentiation potential and contribute to multiple tumor malignancies, such as recurrence, metastasis, heterogeneity, multidrug resistance, and radiation resistance. The biological activities of CSCs are regulated by several pluripotent transcription factors, such as OCT4, Sox2, Nanog, KLF4, and MYC. In addition, many intracellular signaling pathways, such as Wnt, NF-κB (nuclear factor-κB), Notch, Hedgehog, JAK-STAT (Janus kinase/signal transducers and activators of transcription), PI3K/AKT/mTOR (phosphoinositide 3-kinase/AKT/mammalian target of rapamycin), TGF (transforming growth factor)/SMAD, and PPAR (peroxisome proliferator-activated receptor), as well as extracellular factors, such as vascular niches, hypoxia, tumor-associated macrophages, cancer-associated fibroblasts, cancer-associated mesenchymal stem cells, extracellular matrix, and exosomes, have been shown to be very important regulators of CSCs. Molecules, vaccines, antibodies, and CAR-T (chimeric antigen receptor T cell) cells have been developed to specifically target CSCs, and some of these factors are already undergoing clinical trials. This review summarizes the characterization and identification of CSCs, depicts major factors and pathways that regulate CSC development, and discusses potential targeted therapy for CSCs.
Author: Yang, Liqun; Shi, Pengfei; Zhao, Gaichao; Xu, Jie; Peng, Wen; Zhang, Jiayi; Zhang, Guanghui; Wang, Xiaowen; Dong, Zhen; Chen, Fei; Cui, Hongjuan
Automatic Tags: Humans; Signal Transduction; Gene Expression Regulation, Neoplastic; Antineoplastic Agents; Neoplasms; Neoplastic Stem Cells; Transcription Factors; Cancer-Associated Fibroblasts; Immunotherapy, Adoptive; Kruppel-Like Factor 4; NF-kappa B; Tumor-Associated Macrophages
Date: 2020-02-07
Date Added: 3. Mai 2024 09:18 (MESZ)
Date Modified: 14. Mai 2024 11:39 (MESZ)
Extra: PMID: 32296030 PMCID: PMC7005297
File Attachments: ; ; /Users/martin/Zotero/storage/YKA7MNVN/Yang et al_2020_Targeting cancer stem cell pathways for cancer therapy.pdf
ISSN: 2059-3635
Issue: 1
Journal Abbreviation: Signal Transduct Target Ther
Language: eng
Library Catalog: PubMed
Link Attachments: notion://www.notion.so/Yang-et-al-2020-6fe150aae9d2415ebf19ff8f36b144c1; http://www.ncbi.nlm.nih.gov/pubmed/32296030
Manual Tags: notion
Pages: 8
Publication Title: Signal Transduction and Targeted Therapy
Publication Year: 2020
Volume: 5