# Research Paper Planner

## Current draft

↓ Use the page below as your working document

[Research Paper](Research%20Paper%20Planner%2011dad66c1d51810e9939cc6d53e0a962/Research%20Paper%2011dad66c1d5181dc9e49c6d446aebd6c.md)

## Plan

Break down your paper or thesis into milestones with target dates. 

[Plan](Research%20Paper%20Planner%2011dad66c1d51810e9939cc6d53e0a962/Plan%2011dad66c1d5181fd8883d8f1dd8e9383.csv)

## Reading list

Manage the papers, articles and books to read as part of your writeup.

[Reading List](Research%20Paper%20Planner%2011dad66c1d51810e9939cc6d53e0a962/Reading%20List%2011dad66c1d5181f8b5eed2f2d08b33b2.csv)