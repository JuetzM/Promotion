# Research Paper

<aside>
💡 **Notion Tip**: You can leave a comment by selecting any word or text snippet and choosing `Comment` from the menu that pops up. When your report is final you can export it to a PDF by clicking the `•••` icon at the upper right corner of any Notion page then choose `Export` from the dropdown menu.

</aside>

# Kurzfassung

# 1 Hintergrund

# 2 Fragestellung

# 3 Material und Methodology

# 4 Ergebnissse

# 6 Diskussion und Schlussfolgerung

# 6 Literaturverzeichnis

## 

[https://juetzmartin.github.io/juetzmartin/](https://juetzmartin.github.io/juetzmartin/)